package com.dutaduta.sketchme.videoconference.exception;

public class CheckedException extends Exception {
    public CheckedException(String message){
        super(message);
    }
}
