package com.dutaduta.sketchme.videoconference.exception;

public class NoSessionException extends CheckedException{

    public NoSessionException(String message) {
        super(message);
    }
}
