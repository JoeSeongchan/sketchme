package com.dutaduta.sketchme.meeting.domain;

public enum Payment {
    KAKAO, NAVER
}
