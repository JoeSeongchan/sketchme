package com.dutaduta.sketchme.meeting.exception;

import com.dutaduta.sketchme.global.exception.BusinessException;

public class MeetingNotFoundException extends BusinessException {
    public MeetingNotFoundException(){
        super();
    }
}