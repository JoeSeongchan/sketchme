package com.dutaduta.sketchme.meeting.domain;

public enum PaymentStatus {
    PAYMENT_NOT_COMPLELTED,
    PAYMENT_COMPLETED,
    PAYMENT_REFUND_REQUESTED,
    PAYMENT_REFUND_COMPLETED,
    PAYMENT_REFUND_CANCELLED,

}
