package com.dutaduta.sketchme.chat.constant;

public class KafkaConstants {

    public static final String KAFKA_CHAT = "chat";
    public static final String KAFKA_MEETING = "meeting";
    public static final String GROUP_ID_FOR_CHAT = "chat_group";
    public static final String GROUP_ID_FOR_MEETING = "meet_group";

}