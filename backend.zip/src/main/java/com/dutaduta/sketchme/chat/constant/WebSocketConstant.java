package com.dutaduta.sketchme.chat.constant;

public class WebSocketConstant {
    public static final String SUBSCRIBER_URL = "/topic/";
    public static final String PUBLISHER_URL = "/communicate";
    public static final String WEBSOCKET_ENDPOINT = "/ws";
}
