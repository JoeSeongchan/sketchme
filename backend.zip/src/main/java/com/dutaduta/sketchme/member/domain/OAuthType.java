package com.dutaduta.sketchme.member.domain;

public enum OAuthType {
    GOOGLE, KAKAO
}
