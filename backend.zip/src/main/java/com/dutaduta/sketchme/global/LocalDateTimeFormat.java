package com.dutaduta.sketchme.global;


public class LocalDateTimeFormat {
    public static final String DEFAULT = "yyyy-MM-dd'T'HH:mm:ss.SSSSSS";
}
