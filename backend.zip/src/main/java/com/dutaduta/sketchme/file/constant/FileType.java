package com.dutaduta.sketchme.file.constant;

public enum FileType {
    PROFILEUSER, PROFILEARTIST, TIMELAPSE, PICTURE
}
