package com.dutaduta.sketchme.review.exception;

import com.dutaduta.sketchme.global.exception.BusinessException;

public class DuplicatedReviewException extends BusinessException {
    public DuplicatedReviewException(){
        super();
    }
}