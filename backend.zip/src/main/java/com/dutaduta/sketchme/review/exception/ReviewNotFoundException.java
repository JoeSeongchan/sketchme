package com.dutaduta.sketchme.review.exception;

import com.dutaduta.sketchme.global.exception.BusinessException;

public class ReviewNotFoundException extends BusinessException {
    public ReviewNotFoundException(){
        super();
    }
}