package com.dutaduta.sketchme.videoconference.domain;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;


/**
 * QBGM is a Querydsl query type for BGM
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QBGM extends EntityPathBase<BGM> {

    private static final long serialVersionUID = -376429126L;

    public static final QBGM bGM = new QBGM("bGM");

    public final NumberPath<Long> id = createNumber("id", Long.class);

    public final StringPath name = createString("name");

    public final StringPath uri = createString("uri");

    public QBGM(String variable) {
        super(BGM.class, forVariable(variable));
    }

    public QBGM(Path<? extends BGM> path) {
        super(path.getType(), path.getMetadata());
    }

    public QBGM(PathMetadata metadata) {
        super(BGM.class, metadata);
    }

}

