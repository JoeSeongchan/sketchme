package com.dutaduta.sketchme.product.domain;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QFavoritePicture is a Querydsl query type for FavoritePicture
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QFavoritePicture extends EntityPathBase<FavoritePicture> {

    private static final long serialVersionUID = -1212809572L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QFavoritePicture favoritePicture = new QFavoritePicture("favoritePicture");

    public final com.dutaduta.sketchme.common.domain.QBaseEntity _super = new com.dutaduta.sketchme.common.domain.QBaseEntity(this);

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createdDateTime = _super.createdDateTime;

    public final NumberPath<Long> id = createNumber("id", Long.class);

    public final QPicture picture;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updatedDateTime = _super.updatedDateTime;

    public final com.dutaduta.sketchme.member.domain.QUser user;

    public QFavoritePicture(String variable) {
        this(FavoritePicture.class, forVariable(variable), INITS);
    }

    public QFavoritePicture(Path<? extends FavoritePicture> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QFavoritePicture(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QFavoritePicture(PathMetadata metadata, PathInits inits) {
        this(FavoritePicture.class, metadata, inits);
    }

    public QFavoritePicture(Class<? extends FavoritePicture> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.picture = inits.isInitialized("picture") ? new QPicture(forProperty("picture"), inits.get("picture")) : null;
        this.user = inits.isInitialized("user") ? new com.dutaduta.sketchme.member.domain.QUser(forProperty("user"), inits.get("user")) : null;
    }

}

