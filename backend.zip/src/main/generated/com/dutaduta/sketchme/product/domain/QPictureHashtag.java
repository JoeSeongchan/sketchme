package com.dutaduta.sketchme.product.domain;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QPictureHashtag is a Querydsl query type for PictureHashtag
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QPictureHashtag extends EntityPathBase<PictureHashtag> {

    private static final long serialVersionUID = 580886228L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QPictureHashtag pictureHashtag = new QPictureHashtag("pictureHashtag");

    public final com.dutaduta.sketchme.common.domain.QHashtag hashtag;

    public final NumberPath<Long> id = createNumber("id", Long.class);

    public final QPicture picture;

    public QPictureHashtag(String variable) {
        this(PictureHashtag.class, forVariable(variable), INITS);
    }

    public QPictureHashtag(Path<? extends PictureHashtag> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QPictureHashtag(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QPictureHashtag(PathMetadata metadata, PathInits inits) {
        this(PictureHashtag.class, metadata, inits);
    }

    public QPictureHashtag(Class<? extends PictureHashtag> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.hashtag = inits.isInitialized("hashtag") ? new com.dutaduta.sketchme.common.domain.QHashtag(forProperty("hashtag")) : null;
        this.picture = inits.isInitialized("picture") ? new QPicture(forProperty("picture"), inits.get("picture")) : null;
    }

}

