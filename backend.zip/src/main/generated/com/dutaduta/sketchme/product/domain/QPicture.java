package com.dutaduta.sketchme.product.domain;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QPicture is a Querydsl query type for Picture
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QPicture extends EntityPathBase<Picture> {

    private static final long serialVersionUID = -1093045800L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QPicture picture = new QPicture("picture");

    public final com.dutaduta.sketchme.common.domain.QBaseEntity _super = new com.dutaduta.sketchme.common.domain.QBaseEntity(this);

    public final com.dutaduta.sketchme.member.domain.QArtist artist;

    public final com.dutaduta.sketchme.common.domain.QCategory category;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createdDateTime = _super.createdDateTime;

    public final ListPath<PictureHashtag, QPictureHashtag> hashtagList = this.<PictureHashtag, QPictureHashtag>createList("hashtagList", PictureHashtag.class, QPictureHashtag.class, PathInits.DIRECT2);

    public final NumberPath<Long> id = createNumber("id", Long.class);

    public final BooleanPath isDeleted = createBoolean("isDeleted");

    public final BooleanPath isDrawnInApp = createBoolean("isDrawnInApp");

    public final BooleanPath isOpen = createBoolean("isOpen");

    public final com.dutaduta.sketchme.meeting.domain.QMeeting meeting;

    public final StringPath thumbnailUrl = createString("thumbnailUrl");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updatedDateTime = _super.updatedDateTime;

    public final StringPath url = createString("url");

    public final com.dutaduta.sketchme.member.domain.QUser user;

    public QPicture(String variable) {
        this(Picture.class, forVariable(variable), INITS);
    }

    public QPicture(Path<? extends Picture> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QPicture(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QPicture(PathMetadata metadata, PathInits inits) {
        this(Picture.class, metadata, inits);
    }

    public QPicture(Class<? extends Picture> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.artist = inits.isInitialized("artist") ? new com.dutaduta.sketchme.member.domain.QArtist(forProperty("artist"), inits.get("artist")) : null;
        this.category = inits.isInitialized("category") ? new com.dutaduta.sketchme.common.domain.QCategory(forProperty("category"), inits.get("category")) : null;
        this.meeting = inits.isInitialized("meeting") ? new com.dutaduta.sketchme.meeting.domain.QMeeting(forProperty("meeting"), inits.get("meeting")) : null;
        this.user = inits.isInitialized("user") ? new com.dutaduta.sketchme.member.domain.QUser(forProperty("user"), inits.get("user")) : null;
    }

}

