package com.dutaduta.sketchme.meeting.domain;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QMeeting is a Querydsl query type for Meeting
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QMeeting extends EntityPathBase<Meeting> {

    private static final long serialVersionUID = 2088443977L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QMeeting meeting = new QMeeting("meeting");

    public final com.dutaduta.sketchme.common.domain.QBaseEntity _super = new com.dutaduta.sketchme.common.domain.QBaseEntity(this);

    public final com.dutaduta.sketchme.member.domain.QArtist artist;

    public final com.dutaduta.sketchme.common.domain.QCategory category;

    public final com.dutaduta.sketchme.chat.domain.QChatRoom chatRoom;

    public final StringPath content = createString("content");

    //inherited
    public final DateTimePath<java.time.LocalDateTime> createdDateTime = _super.createdDateTime;

    public final NumberPath<Long> exactPrice = createNumber("exactPrice", Long.class);

    public final NumberPath<Long> id = createNumber("id", Long.class);

    public final BooleanPath isOpen = createBoolean("isOpen");

    public final EnumPath<MeetingStatus> meetingStatus = createEnum("meetingStatus", MeetingStatus.class);

    public final EnumPath<Payment> payment = createEnum("payment", Payment.class);

    public final EnumPath<PaymentStatus> paymentStatus = createEnum("paymentStatus", PaymentStatus.class);

    public final com.dutaduta.sketchme.product.domain.QPicture picture;

    public final DateTimePath<java.time.LocalDateTime> startDateTime = createDateTime("startDateTime", java.time.LocalDateTime.class);

    public final com.dutaduta.sketchme.product.domain.QTimelapse timelapse;

    //inherited
    public final DateTimePath<java.time.LocalDateTime> updatedDateTime = _super.updatedDateTime;

    public final com.dutaduta.sketchme.member.domain.QUser user;

    public final StringPath videoConferenceRoomSessionId = createString("videoConferenceRoomSessionId");

    public QMeeting(String variable) {
        this(Meeting.class, forVariable(variable), INITS);
    }

    public QMeeting(Path<? extends Meeting> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QMeeting(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QMeeting(PathMetadata metadata, PathInits inits) {
        this(Meeting.class, metadata, inits);
    }

    public QMeeting(Class<? extends Meeting> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.artist = inits.isInitialized("artist") ? new com.dutaduta.sketchme.member.domain.QArtist(forProperty("artist"), inits.get("artist")) : null;
        this.category = inits.isInitialized("category") ? new com.dutaduta.sketchme.common.domain.QCategory(forProperty("category"), inits.get("category")) : null;
        this.chatRoom = inits.isInitialized("chatRoom") ? new com.dutaduta.sketchme.chat.domain.QChatRoom(forProperty("chatRoom"), inits.get("chatRoom")) : null;
        this.picture = inits.isInitialized("picture") ? new com.dutaduta.sketchme.product.domain.QPicture(forProperty("picture"), inits.get("picture")) : null;
        this.timelapse = inits.isInitialized("timelapse") ? new com.dutaduta.sketchme.product.domain.QTimelapse(forProperty("timelapse"), inits.get("timelapse")) : null;
        this.user = inits.isInitialized("user") ? new com.dutaduta.sketchme.member.domain.QUser(forProperty("user"), inits.get("user")) : null;
    }

}

