package com.dutaduta.sketchme.common.domain;

import static com.querydsl.core.types.PathMetadataFactory.*;

import com.querydsl.core.types.dsl.*;

import com.querydsl.core.types.PathMetadata;
import javax.annotation.processing.Generated;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.dsl.PathInits;


/**
 * QCategoryHashtag is a Querydsl query type for CategoryHashtag
 */
@Generated("com.querydsl.codegen.DefaultEntitySerializer")
public class QCategoryHashtag extends EntityPathBase<CategoryHashtag> {

    private static final long serialVersionUID = -1821363678L;

    private static final PathInits INITS = PathInits.DIRECT2;

    public static final QCategoryHashtag categoryHashtag = new QCategoryHashtag("categoryHashtag");

    public final QCategory category;

    public final QHashtag hashtag;

    public final NumberPath<Long> id = createNumber("id", Long.class);

    public QCategoryHashtag(String variable) {
        this(CategoryHashtag.class, forVariable(variable), INITS);
    }

    public QCategoryHashtag(Path<? extends CategoryHashtag> path) {
        this(path.getType(), path.getMetadata(), PathInits.getFor(path.getMetadata(), INITS));
    }

    public QCategoryHashtag(PathMetadata metadata) {
        this(metadata, PathInits.getFor(metadata, INITS));
    }

    public QCategoryHashtag(PathMetadata metadata, PathInits inits) {
        this(CategoryHashtag.class, metadata, inits);
    }

    public QCategoryHashtag(Class<? extends CategoryHashtag> type, PathMetadata metadata, PathInits inits) {
        super(type, metadata, inits);
        this.category = inits.isInitialized("category") ? new QCategory(forProperty("category"), inits.get("category")) : null;
        this.hashtag = inits.isInitialized("hashtag") ? new QHashtag(forProperty("hashtag")) : null;
    }

}

